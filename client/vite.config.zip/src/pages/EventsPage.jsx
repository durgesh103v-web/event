import { Calendar, CalendarDays, Layers3, MapPin, Search, Users } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import api, { getErrorMessage } from '../api/client';
import EventCard from '../components/EventCard';
import Pagination from '../components/Pagination';
import StatusMessage from '../components/StatusMessage';
import { StyleSheet } from '../styles/StyleSheet';

const filterChips = [
  { label: 'All Categories', value: '' },
  { label: 'Technology', value: 'Technology' },
  { label: 'Business', value: 'Business' },
  { label: 'Cloud', value: 'Cloud' },
  { label: 'Design', value: 'Design' }
];

const useMediaQuery = (query) => {
  const [matches, setMatches] = useState(() => window.matchMedia(query).matches);

  useEffect(() => {
    const mediaQuery = window.matchMedia(query);
    const handleChange = (event) => setMatches(event.matches);

    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, [query]);

  return matches;
};

const EventsPage = () => {
  const isTablet = useMediaQuery('(max-width: 900px)');
  const isMobile = useMediaQuery('(max-width: 600px)');
  const [events, setEvents] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, pages: 1, total: 0 });
  const [search, setSearch] = useState('');
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('');
  const [location, setLocation] = useState('');
  const [date, setDate] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const abortControllerRef = useRef(null);
  const activeAttendees = events.reduce(
    (total, event) => total + (event.attendeeCount || event.attendees?.length || 0),
    0
  );

  const fetchEvents = async (
    page = 1,
    nextQuery = query,
    nextCategory = category,
    nextLocation = location,
    nextDate = date
  ) => {
    abortControllerRef.current?.abort();
    const controller = new AbortController();
    abortControllerRef.current = controller;
    setLoading(true);
    setError('');

    try {
      const { data } = await api.get('/events', {
        signal: controller.signal,
        params: {
          page,
          limit: 10,
          search: nextQuery,
          category: nextCategory || undefined,
          location: nextLocation || undefined,
          date: nextDate || undefined
        }
      });
      setEvents(data.data);
      setPagination(data.pagination);
    } catch (err) {
      if (err.name === 'CanceledError' || err.code === 'ERR_CANCELED') return;
      setError(getErrorMessage(err));
    } finally {
      if (abortControllerRef.current === controller) {
        setLoading(false);
      }
    }
  };

  useEffect(() => {
    fetchEvents(1, '', '', '', '');
    return () => abortControllerRef.current?.abort();
  }, []);

  const handleSearch = (event) => {
    event.preventDefault();
    setQuery(search);
    fetchEvents(1, search, category, location, date);
  };

  const handleCategoryChange = (e) => {
    const val = e.target.value;
    setCategory(val);
    fetchEvents(1, query, val, location, date);
  };

  const handleLocationChange = (e) => {
    const val = e.target.value;
    setLocation(val);
    fetchEvents(1, query, category, val, date);
  };

  const handleDateChange = (e) => {
    const val = e.target.value;
    setDate(val);
    fetchEvents(1, query, category, location, val);
  };

  return (
    <section style={{ ...styles.page, ...(isMobile ? styles.pageMobile : null) }}>
      <div style={{ ...styles.hero, ...(isTablet ? styles.heroTablet : null), ...(isMobile ? styles.heroMobile : null) }}>
        <div aria-hidden="true" style={styles.heroGlow} />
        <div style={styles.heroContent}>
          <span style={styles.heroBadge}>Biz Technologies Assignment</span>
          <h1 style={styles.heroTitle}>
            Event Management System{' '}
            <span style={styles.textHighlight}>MERN Stack Role</span>
          </h1>
          <p style={styles.heroSubtitle}>
            Find events that inspire you. Explore upcoming meetups, workshops, and sessions. Register quickly and track your joined events seamlessly.
          </p>
          
          <div style={styles.heroFeatures}>
            <div style={styles.featureItem}>
              <div style={styles.featureIcon}><Search size={18} /></div>
              <span style={styles.featureText}>Discover</span>
            </div>
            <div style={styles.featureItem}>
              <div style={styles.featureIcon}><Users size={18} /></div>
              <span style={styles.featureText}>Register</span>
            </div>
            <div style={styles.featureItem}>
              <div style={styles.featureIcon}><CalendarDays size={18} /></div>
              <span style={styles.featureText}>Manage</span>
            </div>
          </div>
        </div>

        <div style={{ ...styles.heroImageWrapper, ...(isTablet ? styles.heroImageTablet : null), ...(isMobile ? styles.heroImageMobile : null) }}>
          <div style={{ ...styles.heroImageFrame, ...(isMobile ? styles.heroImageFrameMobile : null) }}>
            <img
              src="https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=760&q=80"
              alt="Audience at an event"
              decoding="async"
              fetchPriority="high"
              style={styles.heroImage}
            />
            <div style={styles.imageShade} />
          </div>
          <div style={{ ...styles.floatingStat, ...(isMobile ? styles.floatingStatMobile : null) }}>
            <div style={styles.statIcon}><Users size={24} /></div>
            <div style={styles.statText}>
              <strong style={styles.statValue}>{activeAttendees}</strong>
              <span style={styles.statLabel}>Registered Attendees</span>
            </div>
          </div>
        </div>
      </div>

      <div style={{ ...styles.searchPanel, ...(isMobile ? styles.searchPanelMobile : null) }}>
        <form style={{ ...styles.searchForm, ...(isTablet ? styles.searchFormTablet : null), ...(isMobile ? styles.searchFormMobile : null) }} onSubmit={handleSearch}>
          <div style={{ ...styles.searchField, ...styles.mainSearch }}>
            <Search size={20} color="#64748b" />
            <input
              aria-label="Search events"
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search by keyword..."
              style={styles.input}
              value={search}
            />
          </div>
          {!isTablet && <div style={styles.divider} />}
          <div style={styles.searchField}>
            <Layers3 size={20} color="#64748b" />
            <select aria-label="Category" style={styles.select} value={category} onChange={handleCategoryChange}>
              {filterChips.map(chip => (
                <option key={chip.label} value={chip.value}>{chip.label}</option>
              ))}
            </select>
          </div>
          {!isTablet && <div style={styles.divider} />}
          <div style={styles.searchField}>
            <MapPin size={20} color="#64748b" />
            <select aria-label="Location" style={styles.select} value={location} onChange={handleLocationChange}>
              <option value="">All Locations</option>
              <option value="Online">Online</option>
              <option value="Mumbai">Mumbai</option>
              <option value="Bengaluru">Bengaluru</option>
            </select>
          </div>
          {!isTablet && <div style={styles.divider} />}
          <div style={styles.searchField}>
            <Calendar size={20} color="#64748b" />
            <select aria-label="Date" style={styles.select} value={date} onChange={handleDateChange}>
              <option value="">Any Date</option>
              <option value="today">Today</option>
              <option value="week">This Week</option>
            </select>
          </div>
          <button type="submit" style={{ ...styles.searchButton, ...(isMobile ? styles.searchButtonMobile : null) }}>Search Events</button>
        </form>
      </div>

      <StatusMessage type="error">{error}</StatusMessage>

      <div style={styles.sectionHeading}>
        <div>
          <h2 style={styles.sectionTitle}>Featured Events</h2>
          <p style={styles.sectionSubtitle}>Handpicked events you won't want to miss.</p>
        </div>
      </div>

      {loading && !events.length ? (
        <div style={styles.emptyState}>Loading events...</div>
      ) : events.length ? (
        <>
          <div style={{ ...styles.eventGrid, ...(isMobile ? styles.eventGridMobile : null), ...(loading ? styles.eventGridUpdating : null) }} aria-busy={loading}>
            {events.map((event) => (
              <EventCard event={event} key={event._id} />
            ))}
          </div>
          <Pagination pagination={pagination} onPageChange={fetchEvents} />
        </>
      ) : (
        <div style={styles.emptyState}>No events found.</div>
      )}
    </section>
  );
};

const styles = StyleSheet.create({
  page: {
    boxSizing: 'border-box',
    display: 'flex',
    flexDirection: 'column',
    gap: 20,
    paddingBottom: 36,
    width: '100%'
  },
  pageMobile: {
    gap: 16
  },
  hero: {
    alignItems: 'center',
    background: '#ffffff',
    border: '1px solid #fed7aa',
    borderRadius: 24,
    boxSizing: 'border-box',
    display: 'grid',
    gap: 'clamp(28px, 3.5vw, 56px)',
    gridTemplateColumns: 'minmax(0, 1.08fr) minmax(400px, 0.92fr)',
    margin: '0 auto',
    maxWidth: 'none',
    overflow: 'hidden',
    padding: '32px clamp(32px, 4vw, 64px)',
    position: 'relative',
    width: '100%',
    boxShadow: '0 18px 48px -36px rgba(15, 23, 42, 0.35)'
  },
  heroTablet: {
    gridTemplateColumns: '1fr'
  },
  heroMobile: {
    gap: 20,
    padding: '22px 18px 28px'
  },
  heroGlow: {
    background: 'radial-gradient(circle, rgba(249, 115, 22, 0.2) 0%, rgba(249, 115, 22, 0) 70%)',
    borderRadius: '50%',
    height: 360,
    left: -190,
    pointerEvents: 'none',
    position: 'absolute',
    top: -210,
    width: 360
  },
  heroContent: {
    display: 'flex',
    flexDirection: 'column',
    gap: 14,
    maxWidth: 650,
    zIndex: 2
  },
  heroBadge: {
    background: 'rgba(255, 255, 255, 0.8)',
    border: '1px solid #fed7aa',
    borderRadius: 999,
    color: '#ea580c',
    display: 'inline-block',
    fontSize: '0.75rem',
    fontWeight: 700,
    letterSpacing: '0.05em',
    padding: '4px 12px',
    textTransform: 'uppercase',
    alignSelf: 'flex-start'
  },
  heroTitle: {
    color: '#0f172a',
    fontSize: 'clamp(2.05rem, 2.6vw, 2.75rem)',
    fontWeight: 800,
    letterSpacing: '-0.035em',
    lineHeight: 1.08,
    margin: 0
  },
  textHighlight: {
    color: '#ea580c',
    display: 'block',
    marginTop: 5
  },
  heroSubtitle: {
    color: '#475569',
    fontSize: '1rem',
    lineHeight: 1.5,
    margin: 0,
    maxWidth: 580
  },
  heroFeatures: {
    display: 'flex',
    flexWrap: 'wrap',
    gap: 10,
    marginTop: 6
  },
  featureItem: {
    alignItems: 'center',
    background: '#fff7ed',
    border: '1px solid #fed7aa',
    borderRadius: 999,
    boxShadow: '0 6px 18px -14px rgba(154, 52, 18, 0.5)',
    display: 'flex',
    gap: 8,
    padding: '7px 11px'
  },
  featureIcon: {
    color: '#ea580c',
    display: 'flex'
  },
  featureText: {
    color: '#1e293b',
    fontSize: '0.9rem',
    fontWeight: 600
  },
  heroImageWrapper: {
    height: 280,
    minWidth: 0,
    position: 'relative',
    width: '100%',
    zIndex: 2
  },
  heroImageTablet: {
    height: 230,
    margin: '0 auto',
    maxWidth: 620
  },
  heroImageMobile: {
    height: 220
  },
  heroImageFrame: {
    border: 0,
    borderRadius: 18,
    boxShadow: '0 20px 40px -28px rgba(15, 23, 42, 0.5)',
    height: '100%',
    overflow: 'hidden',
    position: 'relative',
    width: '100%',
    zIndex: 2
  },
  heroImageFrameMobile: {
    width: '100%'
  },
  heroImage: {
    height: '100%',
    objectFit: 'cover',
    objectPosition: 'center 45%',
    width: '100%'
  },
  imageShade: {
    background: 'linear-gradient(0deg, rgba(15, 23, 42, 0.3), transparent 48%)',
    inset: 0,
    pointerEvents: 'none',
    position: 'absolute'
  },
  floatingStat: {
    alignItems: 'center',
    backdropFilter: 'blur(10px)',
    background: 'rgba(15, 23, 42, 0.82)',
    border: '1px solid rgba(255, 255, 255, 0.16)',
    borderRadius: 12,
    bottom: 14,
    boxShadow: '0 12px 28px -18px rgba(15, 23, 42, 0.6)',
    display: 'flex',
    gap: 12,
    padding: '10px 13px',
    position: 'absolute',
    right: 14,
    zIndex: 3,
    whiteSpace: 'nowrap'
  },
  floatingStatMobile: {
    bottom: 10,
    padding: '9px 12px',
    right: 10
  },
  statIcon: {
    alignItems: 'center',
    background: '#ea580c',
    borderRadius: '50%',
    color: '#ffffff',
    display: 'flex',
    height: 36,
    justifyContent: 'center',
    width: 36
  },
  statText: {
    display: 'flex',
    flexDirection: 'column'
  },
  statValue: {
    color: '#ffffff',
    fontSize: '1.1rem',
    fontWeight: 800,
    lineHeight: 1.1
  },
  statLabel: {
    color: '#cbd5e1',
    fontSize: '0.75rem',
    fontWeight: 600
  },
  searchPanel: {
    background: '#ffffff',
    border: '1px solid #e2e8f0',
    borderRadius: 12,
    boxSizing: 'border-box',
    boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.05)',
    margin: '-16px auto 0',
    maxWidth: 1280,
    padding: 6,
    width: '100%',
    position: 'relative',
    zIndex: 10
  },
  searchPanelMobile: {
    marginTop: -8
  },
  searchForm: {
    alignItems: 'center',
    display: 'flex',
    flexWrap: 'nowrap',
    width: '100%',
    gap: 8
  },
  searchFormTablet: {
    display: 'grid',
    gridTemplateColumns: 'repeat(2, minmax(0, 1fr))'
  },
  searchFormMobile: {
    gridTemplateColumns: '1fr'
  },
  searchField: {
    alignItems: 'center',
    boxSizing: 'border-box',
    display: 'flex',
    flex: '1 1 auto',
    gap: 8,
    padding: '7px 12px'
  },
  mainSearch: {
    flex: '2 1 auto'
  },
  divider: {
    width: 1,
    height: 32,
    backgroundColor: '#e2e8f0'
  },
  input: {
    background: 'transparent',
    border: 0,
    color: '#0f172a',
    fontSize: '0.95rem',
    outline: 'none',
    width: '100%',
    fontFamily: 'inherit'
  },
  select: {
    background: 'transparent',
    border: 0,
    color: '#0f172a',
    cursor: 'pointer',
    fontSize: '0.95rem',
    outline: 'none',
    width: '100%',
    fontFamily: 'inherit'
  },
  searchButton: {
    alignSelf: 'stretch',
    background: '#ea580c',
    border: 0,
    borderRadius: 8,
    color: '#ffffff',
    cursor: 'pointer',
    flex: '0 0 auto',
    fontWeight: 600,
    padding: '0 20px',
    whiteSpace: 'nowrap',
    transition: 'background-color 0.2s ease'
  },
  searchButtonMobile: {
    minHeight: 44
  },
  sectionHeading: {
    maxWidth: 'none',
    margin: '0 auto',
    width: '100%'
  },
  sectionTitle: {
    color: '#0f172a',
    fontSize: '1.5rem',
    fontWeight: 800,
    margin: '0 0 4px'
  },
  sectionSubtitle: {
    color: '#64748b',
    fontSize: '0.92rem',
    margin: 0
  },
  eventGrid: {
    boxSizing: 'border-box',
    display: 'grid',
    gap: 16,
    gridTemplateColumns: 'repeat(auto-fill, minmax(270px, 1fr))',
    margin: '0 auto',
    maxWidth: 'none',
    width: '100%'
  },
  eventGridMobile: {
    gridTemplateColumns: '1fr'
  },
  eventGridUpdating: {
    opacity: 0.6,
    pointerEvents: 'none'
  },
  emptyState: {
    background: '#ffffff',
    border: '1px dashed #cbd5e1',
    borderRadius: 12,
    color: '#64748b',
    margin: '0 auto',
    maxWidth: 1200,
    padding: '48px 24px',
    textAlign: 'center',
    width: '100%'
  }
});

export default EventsPage;
